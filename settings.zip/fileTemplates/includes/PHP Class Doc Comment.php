/**
 * 类描述
 *
 * Class ${NAME}
#if (${NAMESPACE}) * @package ${NAMESPACE}
#end
 *
 * @copyright Copyright (c) 2018-2019 StubbornGrass
 * @license StubbornGrass
 * @version 1.0
 */
