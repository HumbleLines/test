/**
* 
#if (${STATIC} == "static") * @static ${STATIC}  
#end
${PARAM_DOC}
#if (${TYPE_HINT} != "void") * @return ${TYPE_HINT} 
#end
${THROWS_DOC}
* @author StubbornGrass
* @email  g1090035743@gmail.com
* @since  ${YEAR}年${MONTH}月${DAY}日${TIME}
*/
