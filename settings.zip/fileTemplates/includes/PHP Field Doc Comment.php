/**
 * 变量描述
 * @var ${TYPE_HINT}
 */
